import sys
print('\033[91mFAILED \033[0m')